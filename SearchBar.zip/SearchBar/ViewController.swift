//
//  ViewController.swift
//  SearchBar
//
//  Created by SHUBHAM AGARWAL on 30/06/18.
//  Copyright © 2018 SHUBHAM AGARWAL. All rights reserved.
//

import UIKit

