//
//  SponsorsCollectionViewCell.swift
//  Ishicon Mumbai 2018
//
//  Created by user143635 on 11/2/18.
//  Copyright © 2018 atomstudioz. All rights reserved.
//

import UIKit

class SponsorsCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var img: UIImageView!
    
    
}
