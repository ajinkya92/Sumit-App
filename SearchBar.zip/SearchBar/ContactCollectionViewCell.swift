//
//  ContactCollectionViewCell.swift
//  SearchBar
//
//  Created by user143635 on 10/25/18.
//  Copyright © 2018 atomstudioz. All rights reserved.
//

import UIKit

class ContactCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var contactName: UILabel!
    @IBOutlet weak var contactNumber: UILabel!
    
}
